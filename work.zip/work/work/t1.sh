#!/bin/bash
# this is true prod env.

ind=${1:-0}
declare -a servers
servers=(
         10.25.112.51
         10.25.112.52
         10.25.112.53
         10.25.112.54 
         10.25.112.55
         10.25.112.56
         10.25.112.57 10.25.112.58 10.25.112.59 10.25.112.60
         10.10.10.10
#         10.25.17.45
)

last=$(expr ${#servers[@]} - 1)

echo $last

cmd="sshpass -p Hardt0guess@ ssh fgao@"

my_ind=$((ind + 0))

if [ $ind -ge 0 ] &&  [ $ind -le $last ]
then
  echo "haha ${servers[ind]}"
#  $cmd${servers[ind]}
else
  echo "enter an index number between 0 and " $last
fi

