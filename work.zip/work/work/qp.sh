#!/bin/bash


tenv=QPF
ind=${1:-0}
servers=(10.251.36.51 10.251.36.52 10.251.36.53 10.251.36.54 10.251.36.55 10.251.36.56 10.251.36.57 10.251.36.58 10.251.36.59 10.251.36.60)
last=$(expr ${#servers[@]} - 1)

cmd="sshpass -p Dallas123! ssh fgao@"

case $ind in
[0-$last])
  echo "$tenv ${servers[ind]}"
  $cmd${servers[ind]}
  ;;
*)
  echo "enter an index number between 0 and " $last
  ;;
esac

