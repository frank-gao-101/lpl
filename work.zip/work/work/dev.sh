#!/bin/bash

tenv=DEV
ind=${1:-0}
servers=(10.29.80.81 10.29.80.82 10.29.80.83 10.29.80.84 10.29.80.88)
last=$(expr ${#servers[@]} - 1)

cmd="sshpass -p Hardt0guess@ ssh fgao@"

case $ind in
[0-$last])
  echo "$tenv ${servers[ind]}"
  $cmd${servers[ind]}
  ;;
*)
  echo "enter an index number between 0 and " $last
  ;;
esac

