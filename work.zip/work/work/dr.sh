#!/bin/bash

tenv=DR
ind=${1:-0}
servers=(
        10.35.112.51 10.35.112.52 10.35.112.53 10.35.112.54 10.35.112.55
        10.35.112.56 10.35.112.57 10.35.112.58 10.35.112.59 10.35.112.60
)

last=$(expr ${#servers[@]} - 1)

cmd="sshpass -p Hardt0guess@ ssh fgao@"

case $ind in
[0-$last])
  echo "$tenv ${servers[ind]}"
  $cmd${servers[ind]}
  ;;
*)
  echo "enter an index number between 0 and " $last
  ;;
esac

