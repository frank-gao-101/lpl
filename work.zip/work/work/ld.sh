#!/bin/bash

tenv=LDQA
ind=${1:-0}
servers=(10.30.85.194 10.30.85.195 10.30.85.196 10.30.85.197 10.30.85.198 10.30.85.199)
last=$(expr ${#servers[@]} - 1)

cmd="sshpass -p Hardt0guess@ ssh fgao@"

case $ind in
[0-$last])
  echo "$tenv ${servers[ind]}"
  $cmd${servers[ind]}
  ;;
*)
  echo "enter an index number between 0 and " $last
  ;;
esac

