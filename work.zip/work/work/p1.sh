#!/bin/bash

tenv=LEGACY
ind=${1:-0}
servers=(10.25.0.100 10.25.0.101 10.25.0.102 10.25.0.103 10.25.0.104 10.25.0.105)
last=$(expr ${#servers[@]} - 1)

cmd="sshpass -p Hardt0guess@ ssh fgao@"

case $ind in
[0-$last])
  echo "$tenv ${servers[ind]}"
  $cmd${servers[ind]}
  ;;
*)
  echo "enter an index number between 0 and " $last
  ;;
esac

